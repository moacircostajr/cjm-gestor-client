(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./1fcq78hk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.entry.js",
		"common",
		102
	],
	"./1fcq78hk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.sc.entry.js",
		"common",
		103
	],
	"./2i50w2lv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.entry.js",
		"common",
		104
	],
	"./2i50w2lv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.sc.entry.js",
		"common",
		105
	],
	"./39fhulxe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.entry.js",
		"common",
		106
	],
	"./39fhulxe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.sc.entry.js",
		"common",
		107
	],
	"./3hbcnxuc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.entry.js",
		"common",
		58
	],
	"./3hbcnxuc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.sc.entry.js",
		"common",
		59
	],
	"./3pkkvczk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.entry.js",
		0,
		"common",
		128
	],
	"./3pkkvczk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.sc.entry.js",
		0,
		"common",
		129
	],
	"./48sex9p5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.entry.js",
		"common",
		60
	],
	"./48sex9p5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.sc.entry.js",
		"common",
		61
	],
	"./5klmpbas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.entry.js",
		2,
		"common",
		130
	],
	"./5klmpbas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.sc.entry.js",
		2,
		"common",
		131
	],
	"./5zcdwzsx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.entry.js",
		"common",
		10
	],
	"./5zcdwzsx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.sc.entry.js",
		"common",
		11
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		"common",
		12
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		"common",
		13
	],
	"./7hlpr3fd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.entry.js",
		0,
		"common",
		132
	],
	"./7hlpr3fd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.sc.entry.js",
		0,
		"common",
		133
	],
	"./91yswq9n.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.entry.js",
		"common",
		62
	],
	"./91yswq9n.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.sc.entry.js",
		"common",
		63
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		"common",
		64
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		"common",
		65
	],
	"./ak14tg4e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.entry.js",
		"common",
		66
	],
	"./ak14tg4e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.sc.entry.js",
		"common",
		67
	],
	"./azzrjyyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.entry.js",
		0,
		"common",
		134
	],
	"./azzrjyyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.sc.entry.js",
		0,
		"common",
		135
	],
	"./b65tzyas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.entry.js",
		"common",
		14
	],
	"./b65tzyas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.sc.entry.js",
		"common",
		15
	],
	"./b7geaofq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.entry.js",
		"common",
		68
	],
	"./b7geaofq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.sc.entry.js",
		"common",
		69
	],
	"./bb7q7tld.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.entry.js",
		"common",
		108
	],
	"./bb7q7tld.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.sc.entry.js",
		"common",
		109
	],
	"./bheoje2y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.entry.js",
		"common",
		16
	],
	"./bheoje2y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.sc.entry.js",
		"common",
		17
	],
	"./d1xzdckz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.entry.js",
		"common",
		18
	],
	"./d1xzdckz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.sc.entry.js",
		"common",
		19
	],
	"./devt5yhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.entry.js",
		0,
		"common",
		138
	],
	"./devt5yhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.sc.entry.js",
		0,
		"common",
		139
	],
	"./djkq5plb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.entry.js",
		"common",
		70
	],
	"./djkq5plb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.sc.entry.js",
		"common",
		71
	],
	"./eem8jsfz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.entry.js",
		"common",
		20
	],
	"./eem8jsfz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.sc.entry.js",
		"common",
		21
	],
	"./eghwkqif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.entry.js",
		"common",
		22
	],
	"./eghwkqif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.sc.entry.js",
		"common",
		23
	],
	"./ek05jvfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.entry.js",
		"common",
		24
	],
	"./ek05jvfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.sc.entry.js",
		"common",
		25
	],
	"./f5r41bls.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.entry.js",
		0,
		"common",
		110
	],
	"./f5r41bls.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.sc.entry.js",
		0,
		"common",
		111
	],
	"./fkzdmlip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.entry.js",
		140
	],
	"./fkzdmlip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.sc.entry.js",
		141
	],
	"./fmzmhk3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.entry.js",
		"common",
		72
	],
	"./fmzmhk3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.sc.entry.js",
		"common",
		73
	],
	"./foblon1x.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.entry.js",
		"common",
		26
	],
	"./foblon1x.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.sc.entry.js",
		"common",
		27
	],
	"./hds9xywu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.entry.js",
		"common",
		114
	],
	"./hds9xywu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.sc.entry.js",
		"common",
		115
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		142
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		143
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		"common",
		74
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		"common",
		75
	],
	"./imcdx1xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.entry.js",
		"common",
		116
	],
	"./imcdx1xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.sc.entry.js",
		"common",
		117
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		"common",
		76
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		"common",
		77
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		"common",
		78
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		"common",
		79
	],
	"./iwgahuhw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.entry.js",
		"common",
		28
	],
	"./iwgahuhw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.sc.entry.js",
		"common",
		29
	],
	"./j20d1ikn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.entry.js",
		"common",
		80
	],
	"./j20d1ikn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.sc.entry.js",
		"common",
		81
	],
	"./jyhraxns.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.entry.js",
		"common",
		98
	],
	"./jyhraxns.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.sc.entry.js",
		"common",
		99
	],
	"./jzwyowjw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.entry.js",
		"common",
		30
	],
	"./jzwyowjw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.sc.entry.js",
		"common",
		31
	],
	"./k6eoch7h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.entry.js",
		0,
		"common",
		144
	],
	"./k6eoch7h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.sc.entry.js",
		0,
		"common",
		145
	],
	"./kawnb1ql.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.entry.js",
		"common",
		82
	],
	"./kawnb1ql.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.sc.entry.js",
		"common",
		83
	],
	"./kgjnfunx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.entry.js",
		"common",
		32
	],
	"./kgjnfunx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.sc.entry.js",
		"common",
		33
	],
	"./lb8tayd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.entry.js",
		"common",
		118
	],
	"./lb8tayd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.sc.entry.js",
		"common",
		119
	],
	"./llyqw4no.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.entry.js",
		"common",
		84
	],
	"./llyqw4no.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.sc.entry.js",
		"common",
		85
	],
	"./mf2ayo12.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.entry.js",
		"common",
		34
	],
	"./mf2ayo12.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.sc.entry.js",
		"common",
		35
	],
	"./mo7qeek2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.entry.js",
		"common",
		120
	],
	"./mo7qeek2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.sc.entry.js",
		"common",
		121
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		146
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		147
	],
	"./mrs0ks1r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.entry.js",
		0,
		"common",
		148
	],
	"./mrs0ks1r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.sc.entry.js",
		0,
		"common",
		149
	],
	"./n1gqnu4m.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.entry.js",
		"common",
		86
	],
	"./n1gqnu4m.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.sc.entry.js",
		"common",
		87
	],
	"./n60sde1b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.entry.js",
		"common",
		36
	],
	"./n60sde1b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.sc.entry.js",
		"common",
		37
	],
	"./oc7j8k7y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.entry.js",
		"common",
		122
	],
	"./oc7j8k7y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.sc.entry.js",
		"common",
		123
	],
	"./oiucdv63.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.entry.js",
		"common",
		88
	],
	"./oiucdv63.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.sc.entry.js",
		"common",
		89
	],
	"./pd9wflli.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.entry.js",
		"common",
		100
	],
	"./pd9wflli.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.sc.entry.js",
		"common",
		101
	],
	"./qzdsdbvt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.entry.js",
		"common",
		90
	],
	"./qzdsdbvt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.sc.entry.js",
		"common",
		91
	],
	"./r2tscfp8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.entry.js",
		0,
		"common",
		112
	],
	"./r2tscfp8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.sc.entry.js",
		0,
		"common",
		113
	],
	"./r8dtlwvb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.entry.js",
		0,
		"common",
		150
	],
	"./r8dtlwvb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.sc.entry.js",
		0,
		"common",
		151
	],
	"./r8g3twaz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.entry.js",
		"common",
		38
	],
	"./r8g3twaz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.sc.entry.js",
		"common",
		39
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		"common",
		124
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		"common",
		125
	],
	"./ro1otaal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.entry.js",
		2,
		"common",
		152
	],
	"./ro1otaal.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.sc.entry.js",
		2,
		"common",
		153
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		154
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		155
	],
	"./senscofp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.entry.js",
		"common",
		40
	],
	"./senscofp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.sc.entry.js",
		"common",
		41
	],
	"./tg9wqmdk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.entry.js",
		0,
		"common",
		156
	],
	"./tg9wqmdk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.sc.entry.js",
		0,
		"common",
		157
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		"common",
		42
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		"common",
		43
	],
	"./tn7df4wj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.entry.js",
		"common",
		126
	],
	"./tn7df4wj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.sc.entry.js",
		"common",
		127
	],
	"./ugd3sahs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.entry.js",
		"common",
		92
	],
	"./ugd3sahs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.sc.entry.js",
		"common",
		93
	],
	"./uhyavx6a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.entry.js",
		0,
		"common",
		158
	],
	"./uhyavx6a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.sc.entry.js",
		0,
		"common",
		159
	],
	"./upnvzchf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.entry.js",
		"common",
		44
	],
	"./upnvzchf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.sc.entry.js",
		"common",
		45
	],
	"./urrnn8ys.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.entry.js",
		"common",
		46
	],
	"./urrnn8ys.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.sc.entry.js",
		"common",
		47
	],
	"./vompwuhi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.entry.js",
		"common",
		48
	],
	"./vompwuhi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.sc.entry.js",
		"common",
		49
	],
	"./vypdotd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.entry.js",
		"common",
		50
	],
	"./vypdotd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.sc.entry.js",
		"common",
		51
	],
	"./wb4mk1b9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.entry.js",
		0,
		"common",
		160
	],
	"./wb4mk1b9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.sc.entry.js",
		0,
		"common",
		161
	],
	"./wddurbsg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.entry.js",
		"common",
		52
	],
	"./wddurbsg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.sc.entry.js",
		"common",
		53
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		"common",
		94
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		"common",
		95
	],
	"./wpufhrqd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.entry.js",
		"common",
		54
	],
	"./wpufhrqd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.sc.entry.js",
		"common",
		55
	],
	"./wrpzmdqx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.entry.js",
		"common",
		56
	],
	"./wrpzmdqx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.sc.entry.js",
		"common",
		57
	],
	"./wwcmkxu8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.entry.js",
		0,
		"common",
		162
	],
	"./wwcmkxu8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.sc.entry.js",
		0,
		"common",
		163
	],
	"./x5xnv4jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.entry.js",
		0,
		"common",
		164
	],
	"./x5xnv4jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.sc.entry.js",
		0,
		"common",
		165
	],
	"./xajhwvib.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.entry.js",
		"common",
		96
	],
	"./xajhwvib.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.sc.entry.js",
		"common",
		97
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./pages/alunos/alunos.module": [
		"./src/app/pages/alunos/alunos.module.ts",
		"pages-alunos-alunos-module"
	],
	"./pages/colaborador/colaborador.module": [
		"./src/app/pages/colaborador/colaborador.module.ts",
		"common",
		"pages-colaborador-colaborador-module"
	],
	"./pages/colaboradores/colaboradores.module": [
		"./src/app/pages/colaboradores/colaboradores.module.ts",
		"common",
		"pages-colaboradores-colaboradores-module"
	],
	"./pages/login/login.module": [
		"./src/app/pages/login/login.module.ts",
		"pages-login-login-module"
	],
	"./pages/organiza-bancas/organiza-bancas.module": [
		"./src/app/pages/organiza-bancas/organiza-bancas.module.ts",
		"common",
		"pages-organiza-bancas-organiza-bancas-module"
	],
	"./pages/organiza-concursos/organiza-concursos.module": [
		"./src/app/pages/organiza-concursos/organiza-concursos.module.ts",
		"common",
		"pages-organiza-concursos-organiza-concursos-module"
	],
	"./pages/organiza-questoes/organiza-questoes.module": [
		"./src/app/pages/organiza-questoes/organiza-questoes.module.ts",
		"common",
		"pages-organiza-questoes-organiza-questoes-module"
	],
	"./pages/questao/questao.module": [
		"./src/app/pages/questao/questao.module.ts",
		"common",
		"pages-questao-questao-module"
	],
	"./pages/questoes/questoes.module": [
		"./src/app/pages/questoes/questoes.module.ts",
		"common",
		"pages-questoes-questoes-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        // redirectTo: 'home',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './home/home.module#HomePageModule'
    },
    { path: 'questao', loadChildren: './pages/questao/questao.module#QuestaoPageModule' },
    { path: 'questao/:id', loadChildren: './pages/questao/questao.module#QuestaoPageModule' },
    { path: 'questoes', loadChildren: './pages/questoes/questoes.module#QuestoesPageModule' },
    { path: 'organiza-questoes', loadChildren: './pages/organiza-questoes/organiza-questoes.module#OrganizaQuestoesPageModule' },
    { path: 'organiza-bancas', loadChildren: './pages/organiza-bancas/organiza-bancas.module#OrganizaBancasPageModule' },
    { path: 'organiza-concursos', loadChildren: './pages/organiza-concursos/organiza-concursos.module#OrganizaConcursosPageModule' },
    { path: 'login', loadChildren: './pages/login/login.module#LoginPageModule' },
    { path: 'colaboradores', loadChildren: './pages/colaboradores/colaboradores.module#ColaboradoresPageModule' },
    { path: 'colaborador', loadChildren: './pages/colaborador/colaborador.module#ColaboradorPageModule' },
    { path: 'colaborador/:id', loadChildren: './pages/colaborador/colaborador.module#ColaboradorPageModule' },
    { path: 'alunos', loadChildren: './pages/alunos/alunos.module#AlunosPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-split-pane>\n    <ion-menu [hidden]=\"login\">\n      <ion-header>\n        <ion-toolbar>\n          <ion-title>Menu</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content>\n        <ion-list>\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\n              <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n              <ion-label>\n                {{p.title}}\n              </ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet main></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/login.service */ "./src/app/services/login.service.ts");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, loginService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.loginService = loginService;
        this.appPages = [
            {
                title: 'Inicio',
                url: '/home',
                icon: 'home'
            },
            /* {
              title: 'Ferramentas',
              url: '/list',
              icon: 'list'
            }, */
            {
                title: 'Questões',
                url: '/questoes',
                icon: 'list'
            },
            {
                title: 'Matéria',
                url: '/organiza-questoes',
                icon: 'list'
            },
            {
                title: 'Bancas',
                url: '/organiza-bancas',
                icon: 'list'
            },
            {
                title: 'Concursos',
                url: '/organiza-concursos',
                icon: 'list'
            },
            {
                title: 'Colaboradores',
                url: '/colaboradores',
                icon: 'list'
            },
            {
                title: 'Alunos',
                url: '/alunos',
                icon: 'list'
            },
        ];
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    Object.defineProperty(AppComponent.prototype, "login", {
        get: function () {
            return this.loginService.login;
        },
        enumerable: true,
        configurable: true
    });
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _services_login_service__WEBPACK_IMPORTED_MODULE_5__["LoginService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/ngx/index.js");
/* harmony import */ var _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/sqlite/ngx */ "./node_modules/@ionic-native/sqlite/ngx/index.js");
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/network/ngx */ "./node_modules/@ionic-native/network/ngx/index.js");














var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_10__["AppRoutingModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
                _ionic_storage__WEBPACK_IMPORTED_MODULE_8__["IonicStorageModule"].forRoot({
                    name: 'cjm',
                    storeName: 'cjm-cache',
                    driverOrder: ['indexeddb']
                })
            ],
            providers: [
                _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_11__["Camera"],
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
                _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_13__["Network"],
                _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_12__["SQLite"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/services/Config.ts":
/*!************************************!*\
  !*** ./src/app/services/Config.ts ***!
  \************************************/
/*! exports provided: Config */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Config", function() { return Config; });
var Config = /** @class */ (function () {
    function Config() {
    }
    // static SERV_URL = "http://10.0.0.104:62079" /* KZA ITAREMA */
    // static SERV_URL = "http://192.168.11.17:62079/api/admin"
    // static SERV_URL = "http://10.0.0.153:62079" /* "KZA AMONTADA" */
    // static SERV_URL = "http://192.168.43.211:62079"; /* MEU SMARTPHONE */
    // static SERV_URL = "http://192.168.43.211:62079"; /* SMARTPHONE DA PERMANÊNCIA */
    // static SERV_URL = "http://192.168.2.133:62079" /* PPM TRAIRI */
    Config.centralDeTratamentoDeErros = function (error) {
        switch (error) {
            case 500:
                return 'Falha no servidor.';
                break;
            case 400:
                return 'Falha na requisição.';
                break;
            case 401:
                return 'Acesso negado!';
                break;
            case 201:
                return 'Registro efetuado com sucesso!';
                break;
            case 409:
                return 'Email já registrado, por gentileza, tente novamente com outro email.';
                break;
        }
    };
    // LOCAL
    // static SERV_URL = "http://localhost:62079"
    // EXTERNO
    // static SERV_URL = "https://191.242.162.188:62079" /* SITE NA INTERNET */
    Config.SERV_URL = "https://moacircosta.tech:62079"; /* SITE NA INTERNET */
    return Config;
}());



/***/ }),

/***/ "./src/app/services/login.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/login.service.ts ***!
  \*******************************************/
/*! exports provided: LoginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginService", function() { return LoginService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _Config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Config */ "./src/app/services/Config.ts");





var LoginService = /** @class */ (function () {
    function LoginService(httpClient, storage) {
        this.httpClient = httpClient;
        this.storage = storage;
        this.header = {};
        this.gestor = {};
    }
    /*
    obterHeader() {
      this.storage.get('headers-cjm').then(
        (dadosHeaders) => {
          this.header = JSON.parse(dadosHeaders);
        });
      return this.header;
    }
  
    obterGestor() {
      this.storage.get('gestor-cjm').then(
        (dadosGestor) => {
          this.gestor = JSON.parse(dadosGestor);
        });
      return this.gestor;
    }
   */
    LoginService.prototype.logar = function (login) {
        return this.httpClient.post(_Config__WEBPACK_IMPORTED_MODULE_4__["Config"].SERV_URL + '/api/cursos/auth', login);
    };
    LoginService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"]])
    ], LoginService);
    return LoginService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: true
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/moacir/workspace/cjm/cjm-gestor-client/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map